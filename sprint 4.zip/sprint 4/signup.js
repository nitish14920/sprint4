
const arr = [];


function signup(e) {
    e.preventDefault()
    var user = document.getElementById('username').value
    var pass = document.getElementById('password').value
    if (user == "" || pass == "") {
        alert("Empty")
    }
    else {
        var obj = {
            username: user,
            password: pass
        }
        arr.push(obj)
        localStorage.setItem('users', JSON.stringify(arr))
        alert('Sign UP sucessful')
    }
}
