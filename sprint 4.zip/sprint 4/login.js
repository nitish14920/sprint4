function login(e) {
    e.preventDefault()
    var users = JSON.parse(localStorage.getItem('users'))
    var user = document.getElementById('username').value
    var pass = document.getElementById('password').value
    var c = 0;
    for (i = 0; i < users.length; i++){
        
        if (users[i].username == user && users[i].password == pass) {
            c++
            window.location.href="tickets.html"
        }
        
    }
    if (c == 0) {
        alert("Invalid")
    }
}