
const arr = [];
function book1() {
    var name = document.getElementById('1').innerText
    
    console.log(name)
        var obj = {
            movie: name,
            status: "booked"
        }
        arr.push(obj)
    localStorage.setItem('movies', JSON.stringify(arr))
    alert("Movie booked")
    window.location.href="book.html"
    
}